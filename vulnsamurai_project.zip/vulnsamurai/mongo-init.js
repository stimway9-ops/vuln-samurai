// Runs once when the container is first created.
// Creates a least-privilege user for the application.
db = db.getSiblingDB("vulnsamurai");

db.createUser({
  user: process.env.MONGO_APP_USER || "vsapp",
  pwd:  process.env.MONGO_APP_PASS || "changeme_in_env",
  roles: [{ role: "readWrite", db: "vulnsamurai" }]
});

// Create collections with schema validation
db.createCollection("users", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["username", "email", "password_hash", "role", "created_at"],
      properties: {
        username:      { bsonType: "string" },
        email:         { bsonType: "string" },
        password_hash: { bsonType: "string" },
        role:          { bsonType: "string", enum: ["analyst", "admin"] },
        is_active:     { bsonType: "bool" },
      }
    }
  }
});

db.createCollection("scans");
db.createCollection("reports");
db.createCollection("audit_logs");

// Indexes
db.users.createIndex({ username: 1 }, { unique: true });
db.users.createIndex({ email: 1 },    { unique: true });
db.scans.createIndex({ user_id: 1 });
db.scans.createIndex({ status: 1 });
db.reports.createIndex({ user_id: 1 });
db.audit_logs.createIndex({ user_id: 1 });
// TTL — auto-delete logs after 90 days
db.audit_logs.createIndex({ timestamp: 1 }, { expireAfterSeconds: 7776000 });

print("VulnSamurai DB initialised.");
