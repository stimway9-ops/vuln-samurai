import datetime

LOG_FILE = "userlog.txt"

def log_event(event_type, message):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a") as f:
        f.write(f"{timestamp} [{event_type}] {message}\n")
