import os

USERS_FILE = "users.txt"

def load_users():
    if not os.path.exists(USERS_FILE):
        return {}
    users = {}
    with open(USERS_FILE, "r") as f:
        for line in f:
            if ":" in line:
                username, password = line.strip().split(":", 1)
                users[username] = password
    return users

def save_user(username, password):
    with open(USERS_FILE, "a") as f:
        f.write(f"{username}:{password}\n")

def login(username, password):
    users = load_users()
    return username in users and users[username] == password

def register(username, password):
    users = load_users()
    if username in users:
        return False
    save_user(username, password)
    return True
