from flask import Flask, render_template, request, redirect, url_for
from auth import login, register
from logger import log_event

app = Flask(__name__)

# --- Dummy vulnerability data ---
vulnerabilities = [
    {"name": "SQL Injection", "severity": "High", "recommendation": "Use prepared statements"},
    {"name": "Cross-Site Scripting (XSS)", "severity": "Medium", "recommendation": "Validate and sanitize input"},
    {"name": "CSRF", "severity": "Medium", "recommendation": "Use CSRF tokens"},
    {"name": "Unrestricted File Upload", "severity": "High", "recommendation": "Check MIME type & sanitize filenames"},
    {"name": "Broken Access Control", "severity": "Low", "recommendation": "Enforce role-based access control"},
]

payloads = [
    {"vulnerability": "SQL Injection", "payload": "' OR 1=1 --", "result": "Bypass", "result_severity": "High",
     "description": "Login form bypassed using injected condition."},
    {"vulnerability": "XSS", "payload": "<script>alert('XSS')</script>", "result": "Alert Triggered",
     "result_severity": "Medium", "description": "Reflected script executed in user’s browser."},
    {"vulnerability": "CSRF", "payload": "POST /change-email", "result": "Token Missing", "result_severity": "Medium",
     "description": "Malicious form submission succeeded without CSRF token."},
    {"vulnerability": "File Upload", "payload": "shell.php", "result": "Execution", "result_severity": "High",
     "description": "Web shell uploaded via unrestricted file upload."},
    {"vulnerability": "Command Injection", "payload": "; cat /etc/passwd", "result": "System Access",
     "result_severity": "High", "description": "Command injection succeeded with shell command execution."},
]

reports = [
    {"id": "R-2025-01", "name": "Weekly Scan - Prod", "date": "2025-10-15", "findings": 25, "status": "Completed"},
    {"id": "R-2025-02", "name": "Ad-hoc Scan - Staging", "date": "2025-10-22", "findings": 12, "status": "Completed"},
    {"id": "R-2025-03", "name": "Daily Quick Scan", "date": "2025-10-28", "findings": 4, "status": "Completed"},
]

# --- Routes ---

@app.route("/")
def dashboard():
    summary = {"high": 2, "medium": 2, "low": 1, "total": 25}
    log_event("INFO", "Dashboard visited")
    return render_template("index.html",
                           summary=summary,
                           vulnerabilities=vulnerabilities,
                           payloads=payloads)

@app.route("/scan", methods=["POST"])
def scan_page():
    target = request.form["url"]
    log_event("INFO", f"Scan started for {target}")
    log_event("WARN", f"Unusual response size from {target}/upload")
    log_event("ERROR", f"Failed to parse JSON from {target}")
    summary = {"high": 2, "medium": 2, "low": 1, "total": 25}
    return render_template("index.html",
                           summary=summary,
                           vulnerabilities=vulnerabilities,
                           payloads=payloads,
                           message=f"Scan simulated for {target}")

@app.route("/login", methods=["GET", "POST"])
def login_page():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if login(username, password):
            log_event("INFO", f"User {username} logged in")
            return redirect(url_for("dashboard"))
        else:
            log_event("WARN", f"Failed login attempt for {username}")
            return render_template("login.html", error="Invalid credentials")
    log_event("INFO", "Login page visited")
    return render_template("login.html")

@app.route("/register", methods=["POST"])
def register_page():
    username = request.form["username"]
    password = request.form["password"]
    if register(username, password):
        log_event("INFO", f"User {username} registered")
        return redirect(url_for("login_page"))
    else:
        log_event("ERROR", f"Registration failed for {username}")
        return render_template("login.html", error="User already exists")

@app.route("/report")
def report_page():
    log_event("INFO", "Reports page visited")
    return render_template("report.html", reports=reports)

@app.route("/logs")
def logs_page():
    log_event("INFO", "Logs page visited")
    try:
        with open("userlog.txt") as f:
            logs = f.readlines()
    except FileNotFoundError:
        logs = []
    return render_template("logs.html", logs=logs)

# --- Run server ---
if __name__ == "__main__":
    app.run(debug=True)
