/**
 * VulnSamurai — Node.js Frontend
 * Talks to Python FastAPI backend over internal Docker network.
 * Stores JWT in httpOnly session cookies.
 */

const http     = require('http');
const https    = require('https');
const fs       = require('fs');
const path     = require('path');
const qs       = require('querystring');
const url      = require('url');
const crypto   = require('crypto');

const PORT         = process.env.PORT         || 3000;
const BACKEND_URL  = process.env.BACKEND_URL  || 'http://backend:8000';
const SESSION_SECRET = process.env.SESSION_SECRET || 'changeme';

// ─── Cookie session (httpOnly, minimal) ───────────────────────────────────────

const sessions = new Map();  // sessionId → { access_token, refresh_token, username }

function newSession() {
  return crypto.randomBytes(32).toString('hex');
}

function getSession(req) {
  const cookieHeader = req.headers.cookie || '';
  const match = cookieHeader.match(/vs_session=([a-f0-9]+)/);
  if (!match) return null;
  return sessions.get(match[1]) || null;
}

function setSession(res, sessionId, data) {
  sessions.set(sessionId, data);
  res.setHeader('Set-Cookie',
    `vs_session=${sessionId}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400`
  );
}

function clearSession(res, sessionId) {
  if (sessionId) sessions.delete(sessionId);
  res.setHeader('Set-Cookie',
    'vs_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'
  );
}

// ─── Backend API proxy ─────────────────────────────────────────────────────────

function apiRequest(method, endpoint, body, token) {
  return new Promise((resolve, reject) => {
    const parsed  = new URL(BACKEND_URL + endpoint);
    const isHttps = parsed.protocol === 'https:';
    const lib     = isHttps ? https : http;

    const postData = body ? JSON.stringify(body) : null;
    const options  = {
      hostname: parsed.hostname,
      port:     parsed.port || (isHttps ? 443 : 80),
      path:     parsed.pathname + (parsed.search || ''),
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(postData ? { 'Content-Length': Buffer.byteLength(postData) } : {}),
        ...(token    ? { 'Authorization': `Bearer ${token}` } : {}),
      },
    };

    const req = lib.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch { resolve({ status: res.statusCode, body: data }); }
      });
    });

    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

// ─── Template helpers ──────────────────────────────────────────────────────────

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600;700&family=Share+Tech+Mono&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg0:#010513;--bg1:#0a1428;--bg2:rgba(255,255,255,0.04);
  --border:rgba(78,161,255,0.22);--accent:#4ea1ff;--accent2:#2563eb;
  --text:#dde6ff;--muted:#8899bb;
  --high:#ff1744;--medium:#ff9100;--low:#00e676;--info:#64b5f6;
  --font:'Rajdhani',sans-serif;--mono:'Share Tech Mono',monospace;
}
body{font-family:var(--font);background:var(--bg0);color:var(--text);min-height:100vh;overflow-x:hidden}
body::before{content:'';position:fixed;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(78,161,255,0.012) 2px,rgba(78,161,255,0.012) 4px);pointer-events:none;z-index:0}
body::after{content:'';position:fixed;top:-200px;left:50%;transform:translateX(-50%);width:900px;height:600px;background:radial-gradient(ellipse at center,rgba(37,99,235,0.18) 0%,transparent 70%);pointer-events:none;z-index:0}
.navbar{position:sticky;top:0;z-index:100;background:rgba(1,5,19,0.92);backdrop-filter:blur(12px);border-bottom:1px solid var(--border);box-shadow:0 0 24px rgba(0,50,255,0.25);display:flex;justify-content:space-between;align-items:center;padding:0 32px;height:58px}
.navbar-brand{display:flex;align-items:center;gap:10px;text-decoration:none}
.navbar-brand img{height:30px}
.navbar-brand span{font-size:1.15rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--accent);text-shadow:0 0 12px rgba(78,161,255,0.5)}
.navbar-links{display:flex;gap:4px}
.navbar-links a{color:var(--muted);text-decoration:none;font-weight:600;letter-spacing:.8px;text-transform:uppercase;font-size:.82rem;padding:6px 14px;border-radius:3px;border:1px solid transparent;transition:all .2s}
.navbar-links a:hover,.navbar-links a.active{color:var(--accent);border-color:var(--border);background:rgba(78,161,255,0.07)}
.navbar-links a.logout{color:#ff6b6b}
.page{position:relative;z-index:1}
.container{width:92%;max-width:1140px;margin:40px auto}
.section-title{font-size:1rem;font-weight:700;letter-spacing:2.5px;text-transform:uppercase;color:var(--accent);margin-bottom:18px;display:flex;align-items:center;gap:10px}
.section-title::before{content:'';display:inline-block;width:3px;height:16px;background:var(--accent);border-radius:2px;box-shadow:0 0 8px var(--accent)}
.scan-wrap{background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:28px 32px;margin-bottom:32px;box-shadow:0 0 20px rgba(0,50,255,.1)}
.scan-row{display:flex;gap:12px;align-items:center}
.scan-input{flex:1;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:5px;padding:11px 16px;color:var(--text);font-family:var(--mono);font-size:.92rem;outline:none;transition:border-color .2s,box-shadow .2s}
.scan-input:focus{border-color:var(--accent);box-shadow:0 0 10px rgba(78,161,255,.25)}
.scan-input::placeholder{color:var(--muted)}
.btn{position:relative;display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:11px 26px;background:linear-gradient(135deg,var(--accent2),#1e3a8a);color:#fff;border:none;border-radius:5px;font-family:var(--font);font-size:.85rem;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;cursor:pointer;overflow:hidden;transition:transform .15s,box-shadow .2s;box-shadow:0 0 14px rgba(37,99,235,.5);text-decoration:none;white-space:nowrap}
.btn::before{content:'';position:absolute;top:0;left:-100%;width:100%;height:100%;background:linear-gradient(90deg,transparent,rgba(255,255,255,.15),transparent);transition:left .45s ease}
.btn:hover::before{left:100%}
.btn:hover{transform:translateY(-2px);box-shadow:0 0 24px rgba(78,161,255,.6)}
.btn:active{transform:translateY(0)}
.btn-scan{animation:pulse-ring 2.5s ease-out infinite}
@keyframes pulse-ring{0%{box-shadow:0 0 14px rgba(37,99,235,.5),0 0 0 0 rgba(78,161,255,.4)}60%{box-shadow:0 0 14px rgba(37,99,235,.5),0 0 0 10px rgba(78,161,255,0)}100%{box-shadow:0 0 14px rgba(37,99,235,.5),0 0 0 0 rgba(78,161,255,0)}}
.btn-danger{background:linear-gradient(135deg,#b91c1c,#7f1d1d);box-shadow:0 0 14px rgba(185,28,28,.4)}
.btn-sm{padding:6px 14px;font-size:.75rem}
/* Progress bar */
.progress-wrap{margin-top:20px;display:none}
.progress-wrap.active{display:block}
.progress-label{font-size:.8rem;font-family:var(--mono);color:var(--muted);margin-bottom:6px;display:flex;justify-content:space-between}
.progress-bar-outer{height:6px;background:rgba(255,255,255,.06);border-radius:3px;overflow:hidden}
.progress-bar-inner{height:100%;background:linear-gradient(90deg,var(--accent2),var(--accent));border-radius:3px;transition:width .6s ease;width:0%}
.engine-badge{display:inline-block;padding:2px 8px;border-radius:3px;font-family:var(--mono);font-size:.72rem;font-weight:700;letter-spacing:1px;background:rgba(78,161,255,.1);border:1px solid var(--border);color:var(--accent)}
/* Cards */
.cards{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:28px}
.card{flex:1;min-width:190px;background:var(--bg2);border:1px solid var(--border);border-radius:7px;padding:20px 22px;box-shadow:0 0 12px rgba(0,50,255,.08);position:relative;overflow:hidden}
.card::after{content:'';position:absolute;top:0;left:0;width:3px;height:100%;background:var(--accent);opacity:.5}
.card-label{font-size:.72rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--muted);margin-bottom:6px}
.card-value{font-size:2.2rem;font-weight:700;color:var(--accent);line-height:1;font-family:var(--mono)}
.card.high::after{background:var(--high)}.card.medium::after{background:var(--medium)}.card.low::after{background:var(--low)}
.stat-box{background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:22px 24px;margin-bottom:24px;box-shadow:0 0 14px rgba(0,50,255,.1)}
.table{width:100%;border-collapse:collapse;font-size:.9rem}
.table th{background:rgba(78,161,255,.07);color:var(--accent);font-size:.72rem;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;padding:10px 14px;text-align:left;border-bottom:1px solid var(--border)}
.table td{padding:10px 14px;border-bottom:1px solid rgba(78,161,255,.07);color:var(--text);vertical-align:middle}
.table tr:last-child td{border-bottom:none}
.table tr:hover td{background:rgba(78,161,255,.04)}
.badge{display:inline-block;padding:3px 9px;border-radius:3px;font-size:.72rem;font-weight:700;letter-spacing:1px;text-transform:uppercase;font-family:var(--mono)}
.badge.high{background:rgba(255,23,68,.15);color:var(--high);border:1px solid rgba(255,23,68,.35)}
.badge.medium{background:rgba(255,145,0,.12);color:var(--medium);border:1px solid rgba(255,145,0,.35)}
.badge.low{background:rgba(0,230,118,.1);color:var(--low);border:1px solid rgba(0,230,118,.35)}
.badge.info{background:rgba(100,181,246,.1);color:var(--info);border:1px solid rgba(100,181,246,.35)}
.badge.completed,.badge.done{background:rgba(0,230,118,.1);color:var(--low);border:1px solid rgba(0,230,118,.35)}
.badge.running,.badge.pending{background:rgba(255,145,0,.12);color:var(--medium);border:1px solid rgba(255,145,0,.35)}
.badge.failed{background:rgba(255,23,68,.15);color:var(--high);border:1px solid rgba(255,23,68,.35)}
.pill{font-family:var(--mono);font-size:.8rem;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);padding:2px 8px;border-radius:3px;color:#9dc7ff}
.msg-success{margin-top:14px;padding:10px 16px;background:rgba(0,230,118,.08);border:1px solid rgba(0,230,118,.3);border-radius:4px;color:var(--low);font-size:.88rem;font-family:var(--mono)}
.msg-error{margin-top:14px;padding:10px 16px;background:rgba(255,23,68,.08);border:1px solid rgba(255,23,68,.3);border-radius:4px;color:var(--high);font-size:.88rem}
.login-wrap{min-height:calc(100vh - 58px);display:flex;align-items:center;justify-content:center;padding:40px 16px}
.form-box{background:rgba(10,20,40,.85);border:1px solid var(--border);border-radius:10px;padding:36px 40px;width:100%;max-width:400px;box-shadow:0 0 40px rgba(0,50,255,.2)}
.form-box h3{text-align:center;color:var(--accent);font-size:1.3rem;letter-spacing:2px;text-transform:uppercase;margin-bottom:28px}
.form-divider{height:1px;background:var(--border);margin:28px 0}
.form-sub{font-size:.78rem;color:var(--muted);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:16px}
label{font-size:.78rem;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);display:block;margin-bottom:5px}
input[type=text],input[type=password],input[type=url]{width:100%;padding:10px 14px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:4px;color:var(--text);font-family:var(--mono);font-size:.9rem;outline:none;margin-bottom:16px;transition:border-color .2s,box-shadow .2s}
input[type=text]:focus,input[type=password]:focus,input[type=url]:focus{border-color:var(--accent);box-shadow:0 0 8px rgba(78,161,255,.2)}
.search{padding:8px 14px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:4px;color:var(--text);font-family:var(--mono);font-size:.88rem;outline:none;width:280px;margin-bottom:16px}
.search:focus{border-color:var(--accent)}
.log-row.INFO td{color:#8ab4f8}
.log-row.WARN td{color:var(--medium)}
.log-row.ERROR td{color:var(--high)}
`;

function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function sevClass(s) {
  if (!s) return 'info';
  const l = s.toLowerCase();
  if (l === 'high' || l === 'critical') return 'high';
  if (l === 'medium' || l === 'moderate') return 'medium';
  if (l === 'low') return 'low';
  return 'info';
}

function navbar(active = '', session = null) {
  const links = [
    ['/', 'Dashboard'],
    ['/report', 'Reports'],
    ['/logs', 'Logs'],
  ];
  return `
<nav class="navbar">
  <a class="navbar-brand" href="/">
    <img src="/static/logo.svg" alt="VulnSamurai">
    <span>VulnSamurai</span>
  </a>
  <div class="navbar-links">
    ${links.map(([href, label]) =>
      `<a href="${href}"${active === label ? ' class="active"' : ''}>${label}</a>`
    ).join('')}
    ${session
      ? `<a href="/logout" class="logout">Logout (${esc(session.username)})</a>`
      : `<a href="/login"${active === 'Login' ? ' class="active"' : ''}>Login</a>`
    }
  </div>
</nav>`;
}

function shell(title, body, activeNav = '', session = null) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)} — VulnSamurai</title>
<style>${CSS}</style>
</head>
<body>
${navbar(activeNav, session)}
<div class="page">${body}</div>
</body>
</html>`;
}

// ─── Pages ─────────────────────────────────────────────────────────────────────

function pageDashboard(scan = null, message = '', error = '', session = null) {
  const summary = scan?.summary || { high: 0, medium: 0, low: 0, info: 0, total: 0 };
  const vulns   = scan?.vulnerabilities || [];
  const payloads = scan?.payloads || [];
  const scanStatus = scan?.status || '';

  const vulnRows = vulns.length
    ? vulns.map(v => `<tr>
        <td>${esc(v.name)}</td>
        <td><span class="badge ${sevClass(v.severity)}">${esc(v.severity)}</span></td>
        <td><span class="engine-badge">${esc(v.engine)}</span></td>
        <td>${esc(v.recommendation)}</td>
      </tr>`).join('')
    : '<tr><td colspan="4" style="color:var(--muted);text-align:center">No results yet</td></tr>';

  const payloadRows = payloads.length
    ? payloads.map(p => `<tr>
        <td>${esc(p.vulnerability)}</td>
        <td><span class="pill">${esc(p.payload)}</span></td>
        <td><span class="badge ${sevClass(p.result_severity)}">${esc(p.result)}</span></td>
        <td><span class="engine-badge">${esc(p.engine)}</span></td>
        <td>${esc(p.description)}</td>
      </tr>`).join('')
    : '<tr><td colspan="5" style="color:var(--muted);text-align:center">No payloads yet</td></tr>';

  const activeScanId = scan?.id || '';

  return shell('Dashboard', `
<div class="container">

  <div class="scan-wrap" style="animation:fade-up .45s ease">
    <div class="section-title">Start Vulnerability Scan</div>
    <form id="scanForm" action="/scan" method="POST">
      <div class="scan-row">
        <input class="scan-input" type="url" name="url" placeholder="https://target.example.com" required>
        <button class="btn btn-scan" type="submit" id="scanBtn">
          <span class="btn-label">&#9651; Start Scan</span>
        </button>
      </div>
    </form>

    <!-- Live progress bar (shown when scan is running) -->
    <div class="progress-wrap${activeScanId && scanStatus === 'running' ? ' active' : ''}" id="progressWrap">
      <div class="progress-label">
        <span id="engineLabel">Running: <span id="currentEngine">—</span></span>
        <span id="pctLabel">0%</span>
      </div>
      <div class="progress-bar-outer">
        <div class="progress-bar-inner" id="progressBar"></div>
      </div>
    </div>

    ${message ? `<div class="msg-success">&#9654; ${esc(message)}</div>` : ''}
    ${error   ? `<div class="msg-error">&#9888; ${esc(error)}</div>` : ''}
  </div>

  <div class="section-title">Scan Summary</div>
  <div class="cards">
    <div class="card high">  <div class="card-label">High</div>   <div class="card-value" id="cHigh">${summary.high}</div></div>
    <div class="card medium"><div class="card-label">Medium</div> <div class="card-value" id="cMed">${summary.medium}</div></div>
    <div class="card low">   <div class="card-label">Low</div>    <div class="card-value" id="cLow">${summary.low}</div></div>
    <div class="card">       <div class="card-label">Total</div>  <div class="card-value" id="cTotal">${summary.total}</div></div>
  </div>

  <div class="stat-box" id="vulnBox">
    <div class="section-title">Scan Results</div>
    <table class="table" id="vulnTable">
      <thead><tr><th>Vulnerability</th><th>Severity</th><th>Engine</th><th>Recommendation</th></tr></thead>
      <tbody>${vulnRows}</tbody>
    </table>
  </div>

  <div class="stat-box">
    <div class="section-title">Triggered Payloads</div>
    <table class="table" id="payloadTable">
      <thead><tr><th>Vulnerability</th><th>Payload</th><th>Result</th><th>Engine</th><th>Description</th></tr></thead>
      <tbody>${payloadRows}</tbody>
    </table>
  </div>
</div>

<script>
// Poll /api/scans/:id/status every 2s while running
const SCAN_ID = ${JSON.stringify(activeScanId)};
let polling = false;

function updateSummary(s) {
  document.getElementById('cHigh').textContent  = s.high   || 0;
  document.getElementById('cMed').textContent   = s.medium || 0;
  document.getElementById('cLow').textContent   = s.low    || 0;
  document.getElementById('cTotal').textContent = s.total  || 0;
}

function updateProgress(data) {
  const wrap = document.getElementById('progressWrap');
  wrap.classList.add('active');
  const pct = data.progress || 0;
  document.getElementById('progressBar').style.width = pct + '%';
  document.getElementById('pctLabel').textContent    = pct + '%';
  document.getElementById('currentEngine').textContent = data.current_engine || '—';
  if (data.summary) updateSummary(data.summary);
}

async function pollStatus() {
  if (!SCAN_ID || polling) return;
  polling = true;
  const interval = setInterval(async () => {
    try {
      const res  = await fetch('/api/scans/' + SCAN_ID + '/status');
      const data = await res.json();
      updateProgress(data);
      if (data.status === 'done' || data.status === 'failed') {
        clearInterval(interval);
        polling = false;
        // Reload page to show full results
        setTimeout(() => window.location.href = '/?scan=' + SCAN_ID, 800);
      }
    } catch(e) { clearInterval(interval); polling = false; }
  }, 2000);
}

if (SCAN_ID && ${JSON.stringify(scanStatus)} === 'running') {
  pollStatus();
}

// Show progress bar immediately on form submit
document.getElementById('scanForm').addEventListener('submit', function() {
  document.getElementById('scanBtn').disabled = true;
  document.getElementById('progressWrap').classList.add('active');
});
</script>
`, 'Dashboard', session);
}

function pageLogin(error = '') {
  return shell('Login', `
<div class="login-wrap">
  <div class="form-box">
    <h3>&#9876; VulnSamurai</h3>
    <div class="form-sub">Sign In</div>
    <form action="/login" method="POST">
      <label>Username</label>
      <input type="text" name="username" placeholder="samurai" required>
      <label>Password</label>
      <input type="password" name="password" placeholder="••••••" required>
      <button class="btn" style="width:100%" type="submit">Sign In</button>
    </form>
    <div class="form-divider"></div>
    <div class="form-sub">Register New Account</div>
    <form action="/register" method="POST">
      <label>Username</label>
      <input type="text" name="username" placeholder="newuser" required>
      <label>Email</label>
      <input type="text" name="email" placeholder="user@example.com" required>
      <label>Password</label>
      <input type="password" name="password" placeholder="••••••" required>
      <button class="btn btn-danger" style="width:100%" type="submit">Register</button>
    </form>
    ${error ? `<div class="msg-error" style="margin-top:12px">${esc(error)}</div>` : ''}
  </div>
</div>`, 'Login');
}

function pageLogs(logs = [], session = null) {
  const rows = logs.length
    ? logs.map(l => `<tr class="log-row ${esc(l.event_type)}">
        <td>${l.timestamp ? new Date(l.timestamp).toLocaleString() : '—'}</td>
        <td><span class="badge ${l.event_type === 'INFO' ? 'low' : l.event_type === 'WARN' ? 'medium' : 'high'}">${esc(l.event_type)}</span></td>
        <td>${esc(l.message)}</td>
        <td>${esc(l.ip_address || '—')}</td>
      </tr>`).join('')
    : '<tr><td colspan="4" style="color:var(--muted)">No log entries.</td></tr>';

  return shell('Logs', `
<div class="container">
  <div class="section-title">User Logs</div>
  <input class="search" type="text" id="logSearch" placeholder="Filter logs..." oninput="filterLogs(this.value)">
  <div class="stat-box">
    <table class="table" id="logTable">
      <thead><tr><th>Timestamp</th><th>Level</th><th>Message</th><th>IP</th></tr></thead>
      <tbody id="logBody">${rows}</tbody>
    </table>
  </div>
</div>
<script>
function filterLogs(v){
  document.querySelectorAll('#logBody tr').forEach(r=>{
    r.style.display=r.textContent.toLowerCase().includes(v.toLowerCase())?'':'none';
  });
}
</script>`, 'Logs', session);
}

function pageReports(reports = [], session = null) {
  const rows = reports.length
    ? reports.map(r => `<tr>
        <td><span class="pill">${esc(r.id?.slice(-8) || '—')}</span></td>
        <td>${esc(r.name || '—')}</td>
        <td>${r.generated_at ? new Date(r.generated_at).toLocaleDateString() : '—'}</td>
        <td>${esc(String(r.findings || 0))}</td>
        <td><span class="badge ${sevClass(r.status)}">${esc(r.status || '—')}</span></td>
      </tr>`).join('')
    : '<tr><td colspan="5" style="color:var(--muted)">No reports yet.</td></tr>';

  return shell('Reports', `
<div class="container">
  <div class="section-title">Reports</div>
  <div class="stat-box">
    <table class="table">
      <thead><tr><th>ID</th><th>Name</th><th>Date</th><th>Findings</th><th>Status</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div>
</div>`, 'Reports', session);
}

// ─── Helpers ───────────────────────────────────────────────────────────────────

const MIME = {
  '.svg': 'image/svg+xml', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',  '.png': 'image/png',
};

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => resolve(qs.parse(data)));
    req.on('error', reject);
  });
}

function respond(res, status, html) {
  res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(html);
}

function redirect(res, loc) {
  res.writeHead(302, { Location: loc });
  res.end();
}

// ─── Router ────────────────────────────────────────────────────────────────────

const server = http.createServer(async (req, res) => {
  const parsed   = url.parse(req.url);
  const pathname = parsed.pathname;
  const method   = req.method.toUpperCase();
  const session  = getSession(req);

  // ── Static files ──────────────────────────────────────
  if (pathname.startsWith('/static/')) {
    const fp  = path.join(__dirname, pathname);
    const ext = path.extname(fp);
    try {
      const data = fs.readFileSync(fp);
      res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
      return res.end(data);
    } catch { res.writeHead(404); return res.end('Not found'); }
  }

  // ── API proxy — Node.js forwards to Python with JWT ───
  if (pathname.startsWith('/api/')) {
    const apiPath = pathname.replace('/api', '');
    if (!session) { res.writeHead(401); return res.end('{"error":"Unauthorized"}'); }
    try {
      const result = await apiRequest('GET', apiPath, null, session.access_token);
      res.writeHead(result.status, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(result.body));
    } catch (e) { res.writeHead(502); return res.end('{}'); }
  }

  // ── GET / — Dashboard ─────────────────────────────────
  if (pathname === '/' && method === 'GET') {
    const params = new URLSearchParams(parsed.query || '');
    const scanId = params.get('scan');
    let scan = null;
    if (scanId && session) {
      try {
        const r = await apiRequest('GET', `/scans/${scanId}`, null, session.access_token);
        if (r.status === 200) scan = r.body;
      } catch {}
    }
    return respond(res, 200, pageDashboard(scan, '', '', session));
  }

  // ── POST /scan ────────────────────────────────────────
  if (pathname === '/scan' && method === 'POST') {
    if (!session) return redirect(res, '/login');
    const body = await readBody(req);
    try {
      const r = await apiRequest('POST', '/scans', { url: body.url }, session.access_token);
      if (r.status === 202) {
        return redirect(res, `/?scan=${r.body.scan_id}`);
      }
      return respond(res, 200, pageDashboard(null, '', 'Failed to start scan. Is the target URL valid?', session));
    } catch {
      return respond(res, 200, pageDashboard(null, '', 'Backend unreachable.', session));
    }
  }

  // ── GET /login ────────────────────────────────────────
  if (pathname === '/login' && method === 'GET') {
    if (session) return redirect(res, '/');
    return respond(res, 200, pageLogin());
  }

  // ── POST /login ───────────────────────────────────────
  if (pathname === '/login' && method === 'POST') {
    const body = await readBody(req);
    try {
      const r = await apiRequest('POST', '/auth/login',
        { username: body.username, password: body.password });
      if (r.status === 200) {
        const sid = newSession();
        setSession(res, sid, {
          access_token:  r.body.access_token,
          refresh_token: r.body.refresh_token,
          username:      body.username,
        });
        return redirect(res, '/');
      }
      return respond(res, 401, pageLogin('Invalid credentials'));
    } catch {
      return respond(res, 500, pageLogin('Backend unreachable.'));
    }
  }

  // ── POST /register ────────────────────────────────────
  if (pathname === '/register' && method === 'POST') {
    const body = await readBody(req);
    try {
      const r = await apiRequest('POST', '/auth/register',
        { username: body.username, email: body.email, password: body.password });
      if (r.status === 201) return redirect(res, '/login');
      return respond(res, 409, pageLogin(r.body?.detail || 'Registration failed'));
    } catch {
      return respond(res, 500, pageLogin('Backend unreachable.'));
    }
  }

  // ── GET /logout ───────────────────────────────────────
  if (pathname === '/logout' && method === 'GET') {
    const cookieHeader = req.headers.cookie || '';
    const match = cookieHeader.match(/vs_session=([a-f0-9]+)/);
    clearSession(res, match?.[1]);
    return redirect(res, '/login');
  }

  // ── GET /report ───────────────────────────────────────
  if (pathname === '/report' && method === 'GET') {
    let reports = [];
    if (session) {
      try {
        const r = await apiRequest('GET', '/reports', null, session.access_token);
        if (r.status === 200) reports = r.body;
      } catch {}
    }
    return respond(res, 200, pageReports(reports, session));
  }

  // ── GET /logs ─────────────────────────────────────────
  if (pathname === '/logs' && method === 'GET') {
    let logs = [];
    if (session) {
      try {
        const r = await apiRequest('GET', '/logs', null, session.access_token);
        if (r.status === 200) logs = r.body;
      } catch {}
    }
    return respond(res, 200, pageLogs(logs, session));
  }

  // ── 404 ───────────────────────────────────────────────
  respond(res, 404, shell('404', `
    <div class="container" style="text-align:center;padding-top:80px">
      <div class="section-title" style="justify-content:center">404 — Not Found</div>
      <p style="color:var(--muted);margin:16px 0 28px">Path: <code style="font-family:var(--mono)">${esc(pathname)}</code></p>
      <a href="/" class="btn">Go to Dashboard</a>
    </div>`));
});

server.listen(PORT, () => {
  console.log(`\x1b[36m╔════════════════════════════════════╗`);
  console.log(`║   VulnSamurai  ⚔  Frontend         ║`);
  console.log(`║   http://localhost:${PORT}            ║`);
  console.log(`╚════════════════════════════════════╝\x1b[0m`);
});
