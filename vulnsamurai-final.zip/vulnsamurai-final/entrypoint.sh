#!/bin/bash
set -e

mkdir -p /data/db /data/log

INIT_FLAG="/data/db/.initialized"

echo "======================================"
echo "  VulnSamurai starting..."
echo "======================================"

# ── Start MongoDB without auth for init ───────────────────
mongod --dbpath /data/db \
       --logpath /data/log/mongod_init.log \
       --bind_ip 127.0.0.1 \
       --fork --quiet

# Wait for MongoDB
echo "[1/3] Waiting for MongoDB..."
for i in $(seq 1 30); do
    mongosh --quiet --eval "db.adminCommand('ping')" >/dev/null 2>&1 && break
    sleep 1
done

# ── First-time DB setup ────────────────────────────────────
if [ ! -f "$INIT_FLAG" ]; then
    echo "[2/3] Setting up database..."

    APP_USER="${MONGO_APP_USER:-vsapp}"
    APP_PASS="${MONGO_APP_PASS:-vspassword}"

    mongosh --quiet vulnsamurai --eval "
        db.createUser({
            user: '${APP_USER}',
            pwd:  '${APP_PASS}',
            roles: [{ role: 'readWrite', db: 'vulnsamurai' }]
        });
        db.createCollection('users');
        db.createCollection('scans');
        db.createCollection('reports');
        db.createCollection('audit_logs');
        db.users.createIndex({ username: 1 }, { unique: true });
        db.users.createIndex({ email: 1 },    { unique: true });
        db.scans.createIndex({ user_id: 1 });
        db.reports.createIndex({ user_id: 1 });
        db.audit_logs.createIndex({ timestamp: 1 }, { expireAfterSeconds: 7776000 });
        print('DB ready.');
    "

    touch "$INIT_FLAG"
    echo "[2/3] Database initialised."
else
    echo "[2/3] Database already initialised, skipping."
fi

# ── Stop the no-auth mongod ────────────────────────────────
mongosh --quiet admin --eval "db.adminCommand({ shutdown: 1 })" 2>/dev/null || true
sleep 2

echo "[3/3] Starting all services via supervisord..."
echo "======================================"
echo "  Open http://localhost:3000"
echo "======================================"

exec /usr/bin/supervisord -n -c /etc/supervisor/conf.d/vulnsamurai.conf
