# VulnSamurai ⚔

Web application penetration testing tool.
Scan engines: whatweb, nikto, gobuster, wapiti, sqlmap, nuclei.

## Run (one command)

```bash
chmod +x run.sh && ./run.sh
```

Then open: http://localhost:3000

First run takes ~15 minutes (downloads all scan tools).
Every run after that starts in seconds.

## Daily use

```bash
# Start
docker start vulnsamurai

# Stop
docker stop vulnsamurai

# Watch logs
docker logs -f vulnsamurai

# Per-service logs inside the container
docker exec vulnsamurai tail -f /data/log/backend.log
docker exec vulnsamurai tail -f /data/log/frontend.log
docker exec vulnsamurai tail -f /data/log/mongod.log
```

## Rebuild after code changes

```bash
./run.sh
```
