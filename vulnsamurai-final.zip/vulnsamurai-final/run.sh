#!/bin/bash
set -e

echo ""
echo "  ⚔  VulnSamurai — build & run"
echo "======================================"

# Generate a real JWT secret automatically
JWT=$(openssl rand -hex 64)
sed -i "s|changeme_run_openssl_rand_hex_64_and_paste_here|${JWT}|g" .env

echo "[1/2] Building Docker image (first time: ~15 min)..."
docker build -t vulnsamurai .

echo "[2/2] Starting container..."
docker rm -f vulnsamurai 2>/dev/null || true
docker run -d \
  --name vulnsamurai \
  --env-file .env \
  -p 3000:3000 \
  -v vulnsamurai_data:/data \
  vulnsamurai

echo ""
echo "======================================"
echo "  Started! Opening in ~30 seconds."
echo "  http://localhost:3000"
echo "  (run: docker logs -f vulnsamurai)"
echo "======================================"
